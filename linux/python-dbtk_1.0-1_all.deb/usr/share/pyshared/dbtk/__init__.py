"""Database Toolkit

This package contains a framework for creating and running scripts designed to
download published ecological data, and store the data in a database.

"""