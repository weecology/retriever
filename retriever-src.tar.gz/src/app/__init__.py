"""wxPython GUI for EcoData Retriever."""
